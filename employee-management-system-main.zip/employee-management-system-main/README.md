# Employee Management System using Django
This is project is hosted on render - here's the live link 

[https://employee-management-system-mpkc.onrender.com](https://employee-management-system-mpkc.onrender.com/)

(this link might take some time to open as it is hosted on free instance. And please do not spam 🛐)

username - admin  
password - admin123

### How to run this project locally

```bash
git clone https://github.com/thisisnihal/employee-management-system.git
cd employee-management-system
pip install requirements.txt
python manage.py runserver
```

### Sample screenshots

### Login Screen
![](https://imgur.com/GpLwfxy.png)

### Admin Dashboard
![](https://imgur.com/O0FZylE.png)

### Create Employee Page
![](https://imgur.com/pEpNTOa.png)

### List all Employees
![](https://imgur.com/FZvxEAG.png)

### Edit Employee
![](https://imgur.com/YjSPtf7.png)
